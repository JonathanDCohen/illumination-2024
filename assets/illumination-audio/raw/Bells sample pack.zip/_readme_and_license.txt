Sound pack downloaded from Freesound
----------------------------------------

"Sample Pack - BELLS"

This pack of sounds contains sounds by the following user:
 - 15GPanskaKacovaBarbora ( https://freesound.org/people/15GPanskaKacovaBarbora/ )

You can find this pack online at: https://freesound.org/people/15GPanskaKacovaBarbora/packs/26050/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 461172__15gpanskakacovabarbora__05-porcelain-bell.wav
    * url: https://freesound.org/s/461172/
    * license: Creative Commons 0
  * 461171__15gpanskakacovabarbora__01-metal-bell-large.wav
    * url: https://freesound.org/s/461171/
    * license: Creative Commons 0
  * 461170__15gpanskakacovabarbora__02-metal-bell-small.wav
    * url: https://freesound.org/s/461170/
    * license: Creative Commons 0
  * 461169__15gpanskakacovabarbora__03-ceramic-bell.wav
    * url: https://freesound.org/s/461169/
    * license: Creative Commons 0
  * 461168__15gpanskakacovabarbora__04-glazed-bell.wav
    * url: https://freesound.org/s/461168/
    * license: Creative Commons 0


